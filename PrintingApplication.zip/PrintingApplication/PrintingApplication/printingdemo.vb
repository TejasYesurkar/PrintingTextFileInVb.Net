﻿Public Sub GiftReceipt()

	Try

		Dim displayString As String

		Dim ESC As String = Chr(&H1B)

		displayString = ESC + "!" + Chr(1) + ESC + "|cA" + "Store Name" + ESC + "|1lF"
		displayString += ESC + "|cA" + "Store Address" + ESC + "|1lF"
		displayString += ESC + "|2C" + ESC + "|cA" + ESC + "|bC" + "Gift Receipt" + ESC + "|1lF" + ESC + "|1lF"
		displayString += ESC + "|N" + ESC + "!" + Chr(1) + "  Transaction #:  " + vbTab.ToString() + "105" + ESC + "|1lF"

		displayString += "  Date:  " + Date.Today() + vbTab.ToString() + "Time: "

		displayString += DateAndTime.Now().ToLongTimeString() + ESC + "|1lF"

		displayString += "  Cashier:  " + CStr(123) + vbTab.ToString() + "Register:  " + CStr(123) + ESC + "|1lF" + ESC + "|1lF"

		displayString += ESC + "|2uC" + "  Item                 Description           Quantity" + ESC + "|N" + ESC + "!" + Chr(1) + ESC + "|1lF" + ESC + "|1lF" + "  "

		'Iterate loop for each row of the Data Set.
		For k As Integer = 0 To 3 - 1

			'Checking for each row which has selected in DataGrid item.
			If CType("ddd", System.String) = "True" Then

				'Get the Item value from selected row.
				Dim item As String = "Item"

				Dim itemValue As String = String.Empty
				If item.Length > 11 Then
					'if Item length is greater then 11, then take substring of item 0 to 11.
					item = item.Substring(0, 11)
				Else
					'Adding " " in Item string until length 11.
					While item.Length <= 11

						item += " "

					End While

				End If

				displayString += item + vbTab.ToString()
				Dim desc As String = "Item2".ToString()
				Dim descValue As String = String.Empty

				If desc.Length > 20 Then

					'If Description length is greater then 20, then take substring of item 0 to 20.
					desc = desc.Substring(0, 20)

				Else
					While desc.Length <= 20

						'Adding " " in Description string until length 20.
						desc += " "

					End While

				End If

				displayString += desc + vbTab.ToString()
				Dim qnty As String = "ITEM3"
				Dim qntyValue As String = String.Empty

				If qnty.Length > 3 Then

					'If Quantity length is greater then 20, then take substring of quantity 0 to 3.
					qnty = qnty.Substring(0, 3)

				Else

					While qnty.Length <= 3

						'Adding " " in Quantity string until length 20.
						qntyValue += " "
						qnty += " "

					End While

				End If

				qntyValue += qnty.Trim()
				displayString += qntyValue
				displayString += ESC + "|1lF" + "  "

			End If

		Next k

		displayString += ESC + "|1lF"
		displayString += ESC + "|cA" + "Thank You for shopping" + ESC + "|1lF"
		displayString += ESC + "|cA" + "INFOTEC" + ESC + "|1lF"
		displayString += ESC + "|cA" + "We hope you'll come back soon!" + ESC + "|1lF" + ESC + "|1lF" + ESC + "|fP"
		'	_currSess.Register.SetActivePrinterNumber(0)

		'Dim objRp As Object = _currSess.Register.ReceiptPrinter
		'objRp.PrintNormal(2, displayString))

		'		objRp.Release()
		MsgBox("Gift Receipt printed Successfully.")

	Catch ex As Exception

		MsgBox(ex.ToString())

	End Try

End Sub