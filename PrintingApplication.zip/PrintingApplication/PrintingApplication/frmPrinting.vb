﻿Imports System.Drawing.Printing

Public Class frmPrinting

	Dim lstLineToPrint As New List(Of String)

	Private Sub tsOpenfile_Click(sender As Object, e As EventArgs) Handles tsOpenfile.Click
		Dim ObjReader As New System.IO.StreamReader("autocomplete.txt")
		txtfile.Text = ObjReader.ReadToEnd
		ObjReader.Close()
	End Sub

	Private Sub tsPrint_Click(sender As Object, e As EventArgs) Handles tsPrint.Click
		PrintDialog.PrinterSettings = PrintDoc.PrinterSettings
		If PrintDialog.ShowDialog() = Windows.Forms.DialogResult.OK Then
			PrintDoc.PrinterSettings = PrintDialog.PrinterSettings
			Dim PageSetup As New PageSettings
			With PageSetup
				.Margins.Left = 50
				.Margins.Right = 50
				.Margins.Top = 50
				.Margins.Bottom = 50
				.Landscape = False
			End With
			PrintDoc.DefaultPageSettings = PageSetup
		End If
		PrintPreviewDialog1.Document = PrintDoc
		PrintPreviewDialog1.ShowDialog()
	End Sub

	Private Sub PrintDoc_BeginPrint(sender As Object, e As Printing.PrintEventArgs) Handles PrintDoc.BeginPrint
		Dim fntText As Font = txtfile.Font
		Dim txtWidth As Integer = PrintDoc.DefaultPageSettings.PaperSize.Width - PrintDoc.DefaultPageSettings.Margins.Left - PrintDoc.DefaultPageSettings.Margins.Right
		Dim stringSize As SizeF
		Dim g = Me.CreateGraphics
		lstLineToPrint.Clear()
		For intCouner = 0 To txtfile.Lines.Count - 1
			stringSize = g.MeasureString(txtfile.Lines(intCouner), fntText)
			If stringSize.Width < txtWidth Then
				lstLineToPrint.Add(txtfile.Lines(intCouner))
			Else
				Dim LeftMargin As Integer = PrintDoc.DefaultPageSettings.Margins.Left
				Dim TopMargin As Integer = PrintDoc.DefaultPageSettings.Margins.Top
				Dim sfBuffer As SizeF = g.MeasureString("M", fntText)
				Dim LayOutRec As New Rectangle(LeftMargin, TopMargin, txtWidth - sfBuffer.Width, fntText.Height)
				Dim String_format As New Drawing.StringFormat
				String_format.Trimming = StringTrimming.Word
				Dim CharachtersFilter As Integer = 0
				Dim LinesFilled As Integer = 0
				For IntFittedChar = 0 To txtfile.Lines(intCouner).Length - 1
					g.MeasureString(txtfile.Lines(intCouner).Substring(IntFittedChar), fntText, New SizeF(LayOutRec.Width, LayOutRec.Height), String_format, CharachtersFilter, LinesFilled)
					lstLineToPrint.Add(txtfile.Lines(intCouner).Substring(IntFittedChar, CharachtersFilter))
					IntFittedChar += CharachtersFilter - 1

				Next

			End If
		Next

	End Sub

	Private Sub PrintDoc_EndPrint(sender As Object, e As Printing.PrintEventArgs) Handles PrintDoc.EndPrint
		MsgBox("Printing End")
	End Sub

	Private Sub PrintDoc_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDoc.PrintPage

		Static intStart As Integer
		Dim fntText As Font = txtfile.Font
		Dim txtHeight As Integer
		Dim LeftMargin As Integer = PrintDoc.DefaultPageSettings.Margins.Left
		Dim RightMargin As Integer = PrintDoc.DefaultPageSettings.Margins.Right
		Dim TopMargin As Integer = PrintDoc.DefaultPageSettings.Margins.Top
		txtHeight = PrintDoc.DefaultPageSettings.PaperSize.Height - PrintDoc.DefaultPageSettings.Margins.Top - PrintDoc.DefaultPageSettings.Margins.Bottom
		Dim LinesPerPage As Integer = CInt(Math.Round(txtHeight / (fntText.Height + 0.025)))

		e.Graphics.DrawRectangle(Pens.Red, e.MarginBounds)
		Dim intLineNumber As Integer
		For intCounter = intStart To lstLineToPrint.Count - 1
			e.Graphics.DrawString(lstLineToPrint(intCounter), fntText, Brushes.Black, LeftMargin, fntText.Height * intLineNumber + TopMargin)
			intLineNumber += 1
			If intLineNumber > LinesPerPage - 1 Then
				intStart = intCounter
				e.HasMorePages = True
				Exit For
			End If
		Next
	End Sub

	Private Sub PrintDoc_QueryPageSettings(sender As Object, e As Printing.QueryPageSettingsEventArgs) Handles PrintDoc.QueryPageSettings
		MsgBox("Printing Query called")
	End Sub
End Class
