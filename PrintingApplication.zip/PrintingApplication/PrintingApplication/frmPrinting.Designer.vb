﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPrinting
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPrinting))
		Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
		Me.tsOpenfile = New System.Windows.Forms.ToolStripLabel()
		Me.tsPrint = New System.Windows.Forms.ToolStripLabel()
		Me.txtfile = New System.Windows.Forms.TextBox()
		Me.PrintDoc = New System.Drawing.Printing.PrintDocument()
		Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
		Me.PrintDialog = New System.Windows.Forms.PrintDialog()
		Me.ToolStrip1.SuspendLayout()
		Me.SuspendLayout()
		'
		'ToolStrip1
		'
		Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsOpenfile, Me.tsPrint})
		Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
		Me.ToolStrip1.Name = "ToolStrip1"
		Me.ToolStrip1.Size = New System.Drawing.Size(800, 25)
		Me.ToolStrip1.TabIndex = 0
		Me.ToolStrip1.Text = "ToolStrip1"
		'
		'tsOpenfile
		'
		Me.tsOpenfile.Name = "tsOpenfile"
		Me.tsOpenfile.Size = New System.Drawing.Size(57, 22)
		Me.tsOpenfile.Text = "Open File"
		'
		'tsPrint
		'
		Me.tsPrint.Name = "tsPrint"
		Me.tsPrint.Size = New System.Drawing.Size(32, 22)
		Me.tsPrint.Text = "Print"
		'
		'txtfile
		'
		Me.txtfile.Dock = System.Windows.Forms.DockStyle.Fill
		Me.txtfile.Font = New System.Drawing.Font("Trebuchet MS", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtfile.Location = New System.Drawing.Point(0, 25)
		Me.txtfile.Multiline = True
		Me.txtfile.Name = "txtfile"
		Me.txtfile.Size = New System.Drawing.Size(800, 425)
		Me.txtfile.TabIndex = 1
		'
		'PrintDoc
		'
		'
		'PrintPreviewDialog1
		'
		Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
		Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
		Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
		Me.PrintPreviewDialog1.Enabled = True
		Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
		Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
		Me.PrintPreviewDialog1.Visible = False
		'
		'PrintDialog
		'
		Me.PrintDialog.UseEXDialog = True
		'
		'frmPrinting
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(800, 450)
		Me.Controls.Add(Me.txtfile)
		Me.Controls.Add(Me.ToolStrip1)
		Me.Name = "frmPrinting"
		Me.Text = "frmPrinting"
		Me.ToolStrip1.ResumeLayout(False)
		Me.ToolStrip1.PerformLayout()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents ToolStrip1 As ToolStrip
	Friend WithEvents tsOpenfile As ToolStripLabel
	Friend WithEvents tsPrint As ToolStripLabel
	Friend WithEvents txtfile As TextBox
	Friend WithEvents PrintDoc As Printing.PrintDocument
	Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
	Friend WithEvents PrintDialog As PrintDialog
End Class
